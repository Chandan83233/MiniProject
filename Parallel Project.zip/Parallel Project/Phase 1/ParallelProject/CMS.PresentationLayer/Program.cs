﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS.BusinessLogicLayer;
using CMS.Entities;
using CMS.Exceptions;

namespace CMS.PresentationLayer
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;

            do
            {
                PrintMenu();
                Console.WriteLine("\nEnter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        CreateNewCustomer();
                        break;
                    case 2:
                        ViewCustomerSummary();
                        break;
                    case 3:
                        Console.Clear();
                        SearchCustomer();
                        break;
                    case 4:
                        Console.Clear();
                        ModifyCustomer();
                        break;
                    case 5:
                        Console.Clear();
                        RemoveCustomer();
                        break;
                    case 6:
                        SerializeCustomers();
                        break;
                    case 7:
                        DeserializeCustomers();
                        break;
                    case 8:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("\nInvalid Choice!");
                        break;
                }
            } while (choice != 8);
        }

        private static void PrintMenu()
        {
            Console.WriteLine("\n************** CMS Main Menu **************");
            Console.WriteLine("1. Create a new Customer");
            Console.WriteLine("2. View Customer Summary");
            Console.WriteLine("3. Search for an existing Customer");
            Console.WriteLine("4. Modify Customer details");
            Console.WriteLine("5. Remove a Customer");
            Console.WriteLine("6. Serialize Customer Data");
            Console.WriteLine("7. Deserialize Customer Data");
            Console.WriteLine("8. Exit");
            Console.WriteLine("*******************************************\n");

        }

        private static void CreateNewCustomer()
        {
            try
            {
                Customer newCustomer = new Customer();

                Console.WriteLine("\nEnter Customer ID: ");
                newCustomer.CustomerID = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Customer Name: ");
                newCustomer.CustomerName = Console.ReadLine();

                Console.WriteLine("Enter Customer City: ");
                newCustomer.City = Console.ReadLine();

                Console.WriteLine("Enter Customer Age: ");
                newCustomer.Age = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Customer Phone Number (10 digits): ");
                newCustomer.Phone = Convert.ToInt64(Console.ReadLine());

                Console.WriteLine("Enter Customer Pincode (6 digits): ");
                newCustomer.Pincode = Convert.ToInt32(Console.ReadLine());


                bool customerAdded = CustomerBLL.AddCustomerBLL(newCustomer);

                if (customerAdded)
                    Console.WriteLine("\nNew Customer created");
                else
                    Console.WriteLine("\nNew Customer not created");
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void ViewCustomerSummary()
        {
            try
            {
                List<Customer> customerList = CustomerBLL.ListAllCustomersBLL();
                if (customerList.Count > 0)
                {
                    Console.WriteLine("-------------------------------------------------------------------------------");
                    Console.WriteLine("CustomerID\tName\t\tCity\t\tPinCode");
                    Console.WriteLine("-------------------------------------------------------------------------------");
                    foreach (Customer item in customerList)
                    {
                        Console.WriteLine($"{item.CustomerID}\t\t{item.CustomerName}\t\t{item.City}\t\t{item.Pincode}");
                    }
                    Console.WriteLine("-------------------------------------------------------------------------------");

                }
                else
                {
                    Console.WriteLine("\nNo Customer details available");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchCustomer()
        {
            try
            {
                int choice;
                do
                {
                    Console.WriteLine("\n**************Customer Search Menu**************");
                    Console.WriteLine("1. Search Customer By Customer ID");
                    Console.WriteLine("2. Search Customer By Customer Name");
                    Console.WriteLine("3. Go Back to Main Menu");
                    Console.WriteLine("*************************************************\n");

                    Console.WriteLine("\nEnter your Choice:");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:

                            int searchID;
                            Console.WriteLine("\nEnter Customer ID to searched: ");
                            searchID = Convert.ToInt32(Console.ReadLine());

                            Customer customer = CustomerBLL.SearchCustomerByIdBLL(searchID);

                            if(customer!=null)
                            {
                                Console.WriteLine("-------------------------------------------------------------------------------");
                                Console.WriteLine("CustomerID\tName\t\tCity\t\tPinCode");
                                Console.WriteLine("-------------------------------------------------------------------------------");

                                Console.WriteLine($"{customer.CustomerID}\t\t{customer.CustomerName}\t\t{customer.City}\t\t{customer.Pincode}");

                                Console.WriteLine("-------------------------------------------------------------------------------");
                            }
                            else
                            {
                                Console.WriteLine("\nNo Customer details available");
                            }
                            break;
                        case 2:

                            string searchName;
                            Console.WriteLine("\nEnter Customer Name to searched: ");
                            searchName = Console.ReadLine();

                            List<Customer> customerList = CustomerBLL.SearchCustomerByNameBLL(searchName);

                            if(customerList!=null)
                            {
                                Console.WriteLine("-------------------------------------------------------------------------------");
                                Console.WriteLine("CustomerID\tName\t\tCity\t\tPinCode");
                                Console.WriteLine("-------------------------------------------------------------------------------");
                                foreach (Customer item in customerList)
                                {
                                    Console.WriteLine($"{item.CustomerID}\t\t{item.CustomerName}\t\t{item.City}\t\t{item.Pincode}");
                                }
                                Console.WriteLine("-------------------------------------------------------------------------------");


                            }
                            else
                            {
                                Console.WriteLine("\nNo Customer details available ");
                            }

                            break;
                        case 3:
                            Console.Clear();
                            return;
                        default:
                            Console.WriteLine("\nInvalid Choice");
                            break;
                    }
                } while (choice != 3);
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void ModifyCustomer()
        {
            try
            {
                int choice;
                do
                {
                    
                    Console.WriteLine("\n**************Customer Modify Menu**************");
                    Console.WriteLine("1. Modify Customer By Customer ID");
                    Console.WriteLine("2. Modify Customer By Customer Name");
                    Console.WriteLine("3. Modify from Customer Summary");
                    Console.WriteLine("4. Go Back to Main Menu");
                    Console.WriteLine("*************************************************\n");

                    Console.WriteLine("\nEnter your Choice:");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:

                            int updateID;
                            Console.WriteLine("\nEnter Customer ID to modified: ");
                            updateID = Convert.ToInt32(Console.ReadLine());

                            Customer customer = CustomerBLL.SearchCustomerByIdBLL(updateID);

                            if (customer != null)
                            {
                                Console.WriteLine("-------------------------------------------------------------------------------");
                                Console.WriteLine("CustomerID\tName\t\tCity\t\tPinCode");
                                Console.WriteLine("-------------------------------------------------------------------------------");

                                Console.WriteLine($"{customer.CustomerID}\t\t{customer.CustomerName}\t\t{customer.City}\t\t{customer.Pincode}");

                                Console.WriteLine("-------------------------------------------------------------------------------");

                                Console.WriteLine("\nEnter new details: ");
                                Console.WriteLine("\nEnter Customer Name: ");
                                customer.CustomerName = Console.ReadLine();

                                Console.WriteLine("Enter Customer City: ");
                                customer.City = Console.ReadLine();

                                Console.WriteLine("Enter Customer Age: ");
                                customer.Age = Convert.ToInt32(Console.ReadLine());

                                Console.WriteLine("Enter Customer Phone Number (10 digits): ");
                                customer.Phone = Convert.ToInt64(Console.ReadLine());

                                Console.WriteLine("Enter Customer Pincode (6 digits): ");
                                customer.Pincode = Convert.ToInt32(Console.ReadLine());

                                bool customerUpdated = CustomerBLL.ModifyCustomerBLL(customer);

                                if (customerUpdated)
                                    Console.WriteLine("\nCustomer data modified");
                                else
                                    Console.WriteLine("\nCustomer data not modified");
                            }
                            else
                            {
                                Console.WriteLine("\nNo Customer details available");
                            }

                            break;

                        case 2:

                            string updateName;
                            Console.WriteLine("\nEnter Customer Name to modified: ");
                            updateName = Console.ReadLine();

                            List<Customer> customerList = CustomerBLL.SearchCustomerByNameBLL(updateName);

                            if (customerList.Count == 1)
                            {
                                Console.WriteLine("\nEnter Customer Name: ");
                                customerList[0].CustomerName = Console.ReadLine();

                                Console.WriteLine("Enter Customer City: ");
                                customerList[0].City = Console.ReadLine();

                                Console.WriteLine("Enter Customer Age: ");
                                customerList[0].Age = Convert.ToInt32(Console.ReadLine());

                                Console.WriteLine("Enter Customer Phone Number (10 digits): ");
                                customerList[0].Phone = Convert.ToInt64(Console.ReadLine());

                                Console.WriteLine("Enter Customer Pincode (6 digits): ");
                                customerList[0].Pincode = Convert.ToInt32(Console.ReadLine());

                                bool customerUpdated = CustomerBLL.ModifyCustomerBLL(customerList[0]);

                                if (customerUpdated)
                                    Console.WriteLine("\nCustomer data modified");
                                else
                                    Console.WriteLine("\nCustomer data not modified");
                            }

                            
                            else if (customerList.Count > 1)
                            {

                                Console.WriteLine($"\nThere are {customerList.Count} Customers with the Name {updateName} : \n");

                                Console.WriteLine("-------------------------------------------------------------------------------");
                                Console.WriteLine("CustomerID\tName\t\tCity\t\tPinCode");
                                Console.WriteLine("-------------------------------------------------------------------------------");
                                foreach (Customer item in customerList)
                                {
                                    Console.WriteLine($"{item.CustomerID}\t\t{item.CustomerName}\t\t{item.City}\t\t{item.Pincode}");
                                }
                                Console.WriteLine("-------------------------------------------------------------------------------");

                                int updateID1;
                                Console.WriteLine("\nEnter Customer ID to modified: ");
                                updateID1 = Convert.ToInt32(Console.ReadLine());

                                Customer customer1 = CustomerBLL.SearchCustomerByIdBLL(updateID1);

                                if (customer1 != null)
                                {
                                    Console.WriteLine("\nEnter Customer Name: ");
                                    customer1.CustomerName = Console.ReadLine();

                                    Console.WriteLine("Enter Customer City: ");
                                    customer1.City = Console.ReadLine();

                                    Console.WriteLine("Enter Customer Age: ");
                                    customer1.Age = Convert.ToInt32(Console.ReadLine());


                                    Console.WriteLine("Enter Customer Phone Number (10 digits): ");
                                    customer1.Phone = Convert.ToInt64(Console.ReadLine());

                                    Console.WriteLine("Enter Customer Pincode (6 digits): ");
                                    customer1.Pincode = Convert.ToInt32(Console.ReadLine());

                                    bool customerUpdated = CustomerBLL.ModifyCustomerBLL(customer1);

                                    if (customerUpdated)
                                        Console.WriteLine("\nCustomer data modified");
                                    else
                                        Console.WriteLine("\nCustomer data not modified");
                                }
                                else
                                {
                                    Console.WriteLine("\nNo Customer details available");
                                }


                            }
                            else
                            {
                                Console.WriteLine("\nNo Customer details available ");
                            }

                            break;
                        case 3:
                            ViewCustomerSummary();

                            int updateID2;
                            Console.WriteLine("\nEnter Customer ID to modified: ");
                            updateID2 = Convert.ToInt32(Console.ReadLine());

                            Customer customer2 = CustomerBLL.SearchCustomerByIdBLL(updateID2);

                            if (customer2 != null)
                            {
                                Console.WriteLine("\nEnter Customer Name: ");
                                customer2.CustomerName = Console.ReadLine();

                                Console.WriteLine("Enter Customer City: ");
                                customer2.City = Console.ReadLine();

                                Console.WriteLine("Enter Customer Age: ");
                                customer2.Age = Convert.ToInt32(Console.ReadLine());

                                Console.WriteLine("Enter Customer Phone Number (10 digits): ");
                                customer2.Phone = Convert.ToInt64(Console.ReadLine());

                                Console.WriteLine("Enter Customer Pincode (6 digits): ");
                                customer2.Pincode = Convert.ToInt32(Console.ReadLine());

                                bool customerUpdated = CustomerBLL.ModifyCustomerBLL(customer2);

                                if (customerUpdated)
                                    Console.WriteLine("\nCustomer data modified");
                                else
                                    Console.WriteLine("\nCustomer data not modified");
                            }
                            else
                            {
                                Console.WriteLine("\nNo Customer details available");
                            }
                            break;
                        case 4:
                            Console.Clear();
                            return;
                        default:
                            Console.WriteLine("\nInvalid Choice");
                            break;
                    }

                } while (choice != 4);

            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void RemoveCustomer()
        {
            try
            {
                int choice;
                do
                {
                    
                    Console.WriteLine("\n**************Customer Remove Menu**************");
                    Console.WriteLine("1. Remove Customer By Customer ID");
                    Console.WriteLine("2. Remove Customer By Customer Name");
                    Console.WriteLine("3. Remove from Customer Summary");
                    Console.WriteLine("4. Go Back to Main Menu");
                    Console.WriteLine("*************************************************\n");

                    Console.WriteLine("\nEnter your Choice:");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:

                            int deleteID;
                            Console.WriteLine("\nEnter Customer ID to removed: ");
                            deleteID = Convert.ToInt32(Console.ReadLine());

                            Customer customer = CustomerBLL.SearchCustomerByIdBLL(deleteID);

                            if (customer != null)
                            {
                                bool customerDeleted = CustomerBLL.RemoveCustomerBLL(deleteID);

                                if (customerDeleted)
                                    Console.WriteLine("\nCustomer removed");
                                else
                                    Console.WriteLine("\nCustomer not removed ");
                            }
                            else
                            {
                                Console.WriteLine("\nNo Customer details available");
                            }

                            break;
                        case 2:

                            string deleteName;
                            Console.WriteLine("\nEnter Customer Name to removed: ");
                            deleteName = Console.ReadLine();

                            List<Customer> customerList = CustomerBLL.SearchCustomerByNameBLL(deleteName);

                            if (customerList.Count == 1)
                            {
                                bool customerDeleted = CustomerBLL.RemoveCustomerBLL(customerList[0].CustomerID);

                                if (customerDeleted)
                                    Console.WriteLine("\nCustomer removed");
                                else
                                    Console.WriteLine("\nCustomer not removed ");
                            }


                            else if (customerList.Count > 1)
                            {

                                Console.WriteLine($"\nThere are {customerList.Count} Customers with the Name {deleteName} : \n");

                                Console.WriteLine("-------------------------------------------------------------------------------");
                                Console.WriteLine("CustomerID\tName\t\tCity\t\tPinCode");
                                Console.WriteLine("-------------------------------------------------------------------------------");
                                foreach (Customer item in customerList)
                                {
                                    Console.WriteLine($"{item.CustomerID}\t\t{item.CustomerName}\t\t{item.City}\t\t{item.Pincode}");
                                }
                                Console.WriteLine("-------------------------------------------------------------------------------");

                                int deleteID1;
                                Console.WriteLine("\nEnter Customer ID to removed: ");
                                deleteID1 = Convert.ToInt32(Console.ReadLine());

                                Customer customer1 = CustomerBLL.SearchCustomerByIdBLL(deleteID1);

                                if (customer1 != null)
                                {
                                    bool customerDeleted = CustomerBLL.RemoveCustomerBLL(deleteID1);

                                    if (customerDeleted)
                                        Console.WriteLine("\nCustomer removed");
                                    else
                                        Console.WriteLine("\nCustomer not removed ");
                                }
                                else
                                {
                                    Console.WriteLine("\nNo Customer details available");
                                }


                            }
                            else
                            {
                                Console.WriteLine("\nNo Customer details available ");
                            }

                            break;
                        case 3:
                            ViewCustomerSummary();

                            int deleteID2;
                            Console.WriteLine("\nEnter Customer ID to removed: ");
                            deleteID2 = Convert.ToInt32(Console.ReadLine());

                            Customer customer2 = CustomerBLL.SearchCustomerByIdBLL(deleteID2);

                            if (customer2 != null)
                            {
                                bool customerDeleted = CustomerBLL.RemoveCustomerBLL(deleteID2);

                                if (customerDeleted)
                                    Console.WriteLine("\nCustomer removed");
                                else
                                    Console.WriteLine("\nCustomer not removed ");
                            }
                            else
                            {
                                Console.WriteLine("\nNo Customer details available");
                            }
                            break;
                        case 4:
                            Console.Clear();
                            return;
                        default:
                            Console.WriteLine("\nInvalid Choice");
                            break;
                    }

                } while (choice != 4);

            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SerializeCustomers()
        {
            try
            {
                bool customerSerialized = CustomerBLL.SerializeCustomerBLL();

                if (customerSerialized)
                {
                    Console.WriteLine("\nCustomer Data is Serialized");
                }
                else
                {
                    throw new CustomerException("\nCustomer Data is not Serialized");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void DeserializeCustomers()
        {
            try
            {
                List<Customer> deserializeCustList = CustomerBLL.DeserializeCustomerBLL();


                if (deserializeCustList.Count > 0)
                {
                    Console.WriteLine("\nDeserialized Customer data: \n");
                    Console.WriteLine("-------------------------------------------------------------------------------");
                    Console.WriteLine("CustomerID\tName\t\tCity\t\tPinCode");
                    Console.WriteLine("-------------------------------------------------------------------------------");
                    foreach (Customer item in deserializeCustList)
                    {
                        Console.WriteLine($"{item.CustomerID}\t\t{item.CustomerName}\t\t{item.City}\t\t{item.Pincode}");
                    }
                    Console.WriteLine("-------------------------------------------------------------------------------");

                }
                else
                {
                    throw new CustomerException("\nCustomer data not Deserialized");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
