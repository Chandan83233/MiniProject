﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS.Entities;
using CMS.Exceptions;
using System.Data.Common;
using System.Data;

namespace CMS.DataAccessLayer
{
    public class CustomerDAL
    {
        public static bool AddCusotmerDAL(Customer newCustomer)
        {
            bool customerAdded = false;
            try
            {
                DbCommand command = CustomerConnection.CreateCommand();
                command.CommandText = "CK_1998.InsertNewCustomer";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@CustomerName";
                param.DbType = DbType.String;
                param.Value = newCustomer.CustomerName;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@City";
                param.DbType = DbType.String;
                param.Value = newCustomer.City;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Age";
                param.DbType = DbType.Int32;
                param.Value = newCustomer.Age;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Phone";
                param.DbType = DbType.Int64;
                param.Value = newCustomer.Phone;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Pincode";
                param.DbType = DbType.Int32;
                param.Value = newCustomer.Pincode;
                command.Parameters.Add(param);

                int affectedRows = CustomerConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    customerAdded = true;
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (DbException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return customerAdded;
        }

        public static List<Customer> ListAllCustomersDAL()
        {
            List<Customer> customerList = null;
            try
            {
                DbCommand command = CustomerConnection.CreateCommand();
                command.CommandText = "CK_1998.SelectAllCustomers";

                DataTable dataTable = CustomerConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    customerList = new List<Customer>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        Customer customer = new Customer();
                        customer.CustomerID = (int)dataTable.Rows[rowCounter][0];
                        customer.CustomerName = (string)dataTable.Rows[rowCounter][1];
                        customer.City = (string)dataTable.Rows[rowCounter][2];
                        customer.Age = (int)dataTable.Rows[rowCounter][3];
                        customer.Phone = (long)dataTable.Rows[rowCounter][4];
                        customer.Pincode = (int)dataTable.Rows[rowCounter][5];
                        customerList.Add(customer);
                    }
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (DbException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return customerList;
        }

        public static Customer SearchCustomerByIdDAL(int searchCustomerID)
        {
            Customer searchCustomer = null;
            try
            {
                DbCommand command = CustomerConnection.CreateCommand();
                command.CommandText = "CK_1998.SelectCustomer";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@CustomerID";
                param.DbType = DbType.Int32;
                param.Value = searchCustomerID;
                command.Parameters.Add(param);

                DataTable dataTable = CustomerConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    searchCustomer = new Customer();
                    searchCustomer.CustomerID = (int)dataTable.Rows[0][0];
                    searchCustomer.CustomerName = (string)dataTable.Rows[0][1];
                    searchCustomer.City = (string)dataTable.Rows[0][2];
                    searchCustomer.Age = (int)dataTable.Rows[0][3];
                    searchCustomer.Phone = (long)dataTable.Rows[0][4];
                    searchCustomer.Pincode = (int)dataTable.Rows[0][5];

                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (DbException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return searchCustomer;
        }

        public static List<Customer> SearchCustomerByNameDAL(string searchName)
        {
            List<Customer> searchedCustomers = null;

            try
            {
                DbCommand command = CustomerConnection.CreateCommand();
                command.CommandText = "CK_1998.SelectByNameCustomer";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@CustomerName";
                param.DbType = DbType.String;
                param.Value = searchName;
                command.Parameters.Add(param);

                DataTable dataTable = CustomerConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    searchedCustomers = new List<Customer>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        Customer customer = new Customer();
                        customer.CustomerID = (int)dataTable.Rows[rowCounter][0];
                        customer.CustomerName = (string)dataTable.Rows[rowCounter][1];
                        customer.City = (string)dataTable.Rows[rowCounter][2];
                        customer.Age = (int)dataTable.Rows[rowCounter][3];
                        customer.Phone = (long)dataTable.Rows[rowCounter][4];
                        customer.Pincode = (int)dataTable.Rows[rowCounter][5];
                        searchedCustomers.Add(customer);
                    }
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (DbException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return searchedCustomers;
        }

        public static bool ModifyCustomerDAL(Customer updateCustomer)
        {
            bool customerUpdated = false;
            try
            {
                DbCommand command = CustomerConnection.CreateCommand();
                command.CommandText = "Ck_1998.ModifyCustomer";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@CustomerID";
                param.DbType = DbType.String;
                param.Value = updateCustomer.CustomerID;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@CustomerName";
                param.DbType = DbType.String;
                param.Value = updateCustomer.CustomerName;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@City";
                param.DbType = DbType.String;
                param.Value = updateCustomer.City;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Age";
                param.DbType = DbType.Int32;
                param.Value = updateCustomer.Age;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Phone";
                param.DbType = DbType.Int64;
                param.Value = updateCustomer.Phone;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@Pincode";
                param.DbType = DbType.Int32;
                param.Value = updateCustomer.Pincode;
                command.Parameters.Add(param);

                int affectedRows = CustomerConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    customerUpdated = true;
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (DbException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return customerUpdated;
        }

        public static bool RemoveCustomerDAL(int deleteCustomerID)
        {
            bool customerDeleted = false;
            try
            {
                DbCommand command = CustomerConnection.CreateCommand();
                command.CommandText = "CK_1998.RemoveCustomer";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@CustomerID";
                param.DbType = DbType.Int32;
                param.Value = deleteCustomerID;
                command.Parameters.Add(param);

                int affectedRows = CustomerConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    customerDeleted = true;
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (DbException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return customerDeleted;
        }

        public static string ReturnCustomerIdDAL ()
        {

            DbCommand command = CustomerConnection.CreateCommand();
            command.CommandText = "CK_1998.ReturnCustomerID";

            string customerID = CustomerConnection.ExecuteScalarCommand(command).ToString(); 

            return customerID; 
        }
    }
}
