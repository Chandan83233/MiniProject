USE Training_13Aug19_Pune
GO

create schema [CK_1998]
go

 Create TABLE [CK_1998].[Customer]
(
CustomerID INT PRIMARY KEY IDENTITY(1,1),
CustomerName VARCHAR(50) NOT NULL,
City VARCHAR(30) NOT NULL,
Age INT NOT NULL,
Phone BIGINT NOT NULL,
Pincode INT NOT NULL
);

CREATE PROCEDURE [CK_1998].[InsertNewCustomer]
@CustomerName VARCHAR(50),
@City VARCHAR(30),
@Age INT,
@Phone BIGINT,
@Pincode INT
AS
BEGIN
	INSERT INTO [CK_1998].[Customer] VALUES (@CustomerName,@City,@Age,@Phone,@Pincode)
END

exec [CK_1998].[InsertNewCustomer] @CustomerName='Chandan',@City='Patna',@Age=21,@Phone=9973397246,@Pincode=800001;

CREATE PROCEDURE [CK_1998].[SelectAllCustomers]
AS
BEGIN
	SELECT * FROM [CK_1998].[Customer]
END

CREATE PROCEDURE [CK_1998].[SelectCustomer]
@CustomerID INT
AS
BEGIN
	SELECT * FROM [CK_1998].[Customer] WHERE CustomerID=@CustomerID
END

CREATE PROCEDURE [CK_1998].[ModifyCustomer]
@CustomerID INT,
@CustomerName VARCHAR(50),
@City VARCHAR(30),
@Age INT,
@Phone BIGINT,
@Pincode INT
AS
BEGIN
	UPDATE [CK_1998].[Customer] SET CustomerName=@CustomerName, City=@City, Age=@Age, Phone=@Phone, Pincode=@Pincode WHERE CustomerID=@CustomerID
END

CREATE PROCEDURE [CK_1998].[removeCustomer]
@CustomerID INT
AS
BEGIN
	DELETE FROM [CK_1998].[Customer] WHERE CustomerID=@CustomerID
END

CREATE PROCEDURE [CK_1998].[SelectByNameCustomer]
@CustomerName VARCHAR(50)
AS
BEGIN
	SELECT * FROM [CK_1998].[Customer] WHERE CustomerName Like ('%'+@CustomerName+'%') AND @CustomerName <> ''
END

CREATE PROCEDURE [CK_1998].[ReturnCustomerID]
AS
BEGIN
	SELECT IDENT_CURRENT('[CK_1998].[Customer]')+1
END


select * from [CK_1998].Customer
