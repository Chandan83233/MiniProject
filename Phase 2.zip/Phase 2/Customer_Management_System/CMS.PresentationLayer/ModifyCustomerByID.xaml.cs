﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CMS.BusinessLogicLayer;
using CMS.Entities;
using CMS.Exceptions;

namespace CMS.PresentationLayer
{
    /// <summary>
    /// Interaction logic for ModifyCustomerByID.xaml
    /// </summary>
    public partial class ModifyCustomerByID : Window
    {
        public ModifyCustomerByID()
        {
            InitializeComponent();
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int searchCustomerID;

                if (string.IsNullOrEmpty(txtID.Text))
                {
                    MessageBox.Show("Customer ID cannot be null or empty");
                }
                else
                {
                    searchCustomerID = Convert.ToInt32(txtID.Text);
                    Customer searchCustomer = CustomerBLL.SearchCustomerByIdBLL(searchCustomerID);
                    if (searchCustomer != null)
                    {
                        txtName.Text = searchCustomer.CustomerName;
                        txtCity.Text = searchCustomer.City;
                        txtAge.Text = searchCustomer.Age.ToString();
                        txtPhone.Text = searchCustomer.Phone.ToString();
                        txtPincode.Text = searchCustomer.Pincode.ToString();
                    }
                    else
                    {
                        MessageBox.Show("No Customer details available");
                    }
                }
                

            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try {

                int updateCustomerID = Convert.ToInt32(txtID.Text);

                Customer updatedCustomer = CustomerBLL.SearchCustomerByIdBLL(updateCustomerID);

                if (updatedCustomer != null)
                {
                    updatedCustomer.CustomerName = txtName.Text;
                    updatedCustomer.City = txtCity.Text;
                    string age = "0" + txtAge.Text;
                    updatedCustomer.Age = Convert.ToInt32(age);
                    string phn = "0" + txtPhone.Text;
                    updatedCustomer.Phone = Convert.ToInt64(phn);
                    string pin = "0" + txtPincode.Text;
                    updatedCustomer.Pincode = Convert.ToInt32(pin);

                    bool customerUpdated = CustomerBLL.ModifyCustomerBLL(updatedCustomer);

                    if (customerUpdated)
                    {
                        MessageBox.Show("Customer modified");
                        txtID.Text = "";
                        txtName.Text = "";
                        txtCity.Text = "";
                        txtAge.Text = "";
                        txtPhone.Text = "";
                        txtPincode.Text = "";
                    }
                        
                    else
                        MessageBox.Show("Customer could not be modified");
                }
                else
                {
                    MessageBox.Show("No Customer details available");
                }

            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        

        private void Window_Closed(object sender, EventArgs e)
        {
            ModifyCustomerMenu.modifyMenuWin1.EnableAllButtons();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            this.Close();

        }
    }
}
