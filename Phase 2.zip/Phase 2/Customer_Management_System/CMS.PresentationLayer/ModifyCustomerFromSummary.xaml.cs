﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CMS.BusinessLogicLayer;
using CMS.Entities;
using CMS.Exceptions;

namespace CMS.PresentationLayer
{
    /// <summary>
    /// Interaction logic for ModifyCustomerFromSummary.xaml
    /// </summary>
    public partial class ModifyCustomerFromSummary : Window
    {
        public ModifyCustomerFromSummary()
        {
            InitializeComponent();
            List<Customer> customerList = CustomerBLL.ListAllCustomersBLL();
            if (customerList.Count > 0)
            {
                dgCustomers.HeadersVisibility = DataGridHeadersVisibility.All;
            }
            dgCustomers.ItemsSource = customerList.ToList();
        }

        private void BtnModify_Click(object sender, RoutedEventArgs e)
        {
            Customer row = (Customer)dgCustomers.SelectedItem;

            Customer updatedCustomer = new Customer();

            if (row != null)
            {
                updatedCustomer.CustomerID = row.CustomerID;
                updatedCustomer.CustomerName = row.CustomerName;
                updatedCustomer.City = row.City;
                updatedCustomer.Age = row.Age;
                updatedCustomer.Phone = row.Phone;
                updatedCustomer.Pincode = row.Pincode;

                bool customerUpdated = CustomerBLL.ModifyCustomerBLL(updatedCustomer);

                if (customerUpdated)
                {
                    MessageBox.Show("Customer modified");
                    dgCustomers.ItemsSource = CustomerBLL.ListAllCustomersBLL();
                }

                else
                    MessageBox.Show("Customer could not be modified");
            }
            else
            {
                MessageBox.Show("No Customer selected");
            }
            
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            ModifyCustomerMenu.modifyMenuWin1.EnableAllButtons();
        }

        

        private void BtnBack_Click_1(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
