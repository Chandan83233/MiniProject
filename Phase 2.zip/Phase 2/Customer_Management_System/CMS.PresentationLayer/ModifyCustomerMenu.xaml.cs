﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CMS.PresentationLayer
{
    /// <summary>
    /// Interaction logic for ModifyCustomerMenu.xaml
    /// </summary>
    public partial class ModifyCustomerMenu : Window
    {
        public static ModifyCustomerMenu modifyMenuWin1;
        public ModifyCustomerMenu()
        {
            InitializeComponent();
            modifyMenuWin1 = this;
        }

        private void DisableAllButtons()
        {
            btnModifyByID.IsEnabled = false;
            btnModifyByName.IsEnabled = false;
            btnModifyMenu.IsEnabled = false;

            btnExit.IsEnabled = false;
        }

        public void EnableAllButtons()
        {
            btnModifyByID.IsEnabled = true;
            btnModifyByName.IsEnabled = true;
            btnModifyMenu.IsEnabled = true;

            btnExit.IsEnabled = true;
        }

        private void BtnModifyByID_Click(object sender, RoutedEventArgs e)
        {
            ModifyCustomerByID win1 = new ModifyCustomerByID();
            win1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            win1.Show();
            DisableAllButtons();
        }

        private void BtnModifyByName_Click(object sender, RoutedEventArgs e)
        {
            ModifyCustomerByName win2 = new ModifyCustomerByName();
            win2.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            win2.Show();
            DisableAllButtons();
        }

        private void BtnModifyMenu_Click(object sender, RoutedEventArgs e)
        {
            ModifyCustomerFromSummary win3 = new ModifyCustomerFromSummary();
            win3.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            win3.Show();
            DisableAllButtons();
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            CMSMainMenu.mainWin1.EnableAllButtons();
        }
    }
}
