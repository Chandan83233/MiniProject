﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CMS.BusinessLogicLayer;
using CMS.Entities;
using CMS.Exceptions;

namespace CMS.PresentationLayer
{
    /// <summary>
    /// Interaction logic for ModifyCustomerByName.xaml
    /// </summary>
    public partial class ModifyCustomerByName : Window
    {
        public ModifyCustomerByName()
        {
            InitializeComponent();
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if(string.IsNullOrEmpty(txtName.Text))
                {
                    MessageBox.Show("Customer Name cannot be null or empty");
                }
                else
                {
                    string searchCustomerName = txtName.Text;

                    List<Customer> searchCustomers = CustomerBLL.SearchCustomerByNameBLL(searchCustomerName);

                    if (searchCustomers != null)
                    {
                        dgCustomers.HeadersVisibility = DataGridHeadersVisibility.All;
                        dgCustomers.ItemsSource = searchCustomers;

                    }
                    else
                    {
                        dgCustomers.HeadersVisibility = DataGridHeadersVisibility.None;
                        dgCustomers.ItemsSource = searchCustomers;
                        MessageBox.Show("No Customer details available");
                    }
                }
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnModify_Click(object sender, RoutedEventArgs e)
        {
            Customer row = (Customer)dgCustomers.SelectedItem;

            Customer updatedCustomer = new Customer();

            if(row!=null)
            {
                updatedCustomer.CustomerID = row.CustomerID;
                updatedCustomer.CustomerName = row.CustomerName;
                updatedCustomer.City = row.City;
                updatedCustomer.Age = row.Age;
                updatedCustomer.Phone = row.Phone;
                updatedCustomer.Pincode = row.Pincode;

                bool customerUpdated = CustomerBLL.ModifyCustomerBLL(updatedCustomer);

                if (customerUpdated)
                {
                    MessageBox.Show("Customer modified");
                    string searchCustomerName = txtName.Text;
                    dgCustomers.ItemsSource = CustomerBLL.SearchCustomerByNameBLL(searchCustomerName);
                }

                else
                    MessageBox.Show("Customer could not be modified");
            }
            else
            {
                MessageBox.Show("No Customer selected");
            }
            
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            ModifyCustomerMenu.modifyMenuWin1.EnableAllButtons();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
