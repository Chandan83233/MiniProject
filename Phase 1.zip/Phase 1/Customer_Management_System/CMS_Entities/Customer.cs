﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS_Entities
{
    public class Customer
    {
        public int CustomerID { get; set; }
        public string CustomerName { get; set; }
        public string City { get; set; }
        public int Age { get; set; }
        public long Phone { get; set; }
        public int Pincode { get; set; }

        public Customer()
        {

        }

        public Customer(int customerID, string customerName, string city, int age, long phone, int pincode)
        {
            CustomerID = customerID;
            CustomerName = customerName;
            City = city;
            Age = age;
            Phone = phone;
            Pincode = pincode;
        }
    }
}
