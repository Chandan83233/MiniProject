﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS_BuisenessLayer;
using CMS_Entities;
using CMS_Exception;

namespace MiniProject_CMS
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;

            try
            {
                do
                {
                    PrintMenu();
                    Console.Write("Enter your choice : ");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            CreateNewCustomer();
                            break;
                        case 2:
                            
                            Console.Clear();
                            ModifyCustomer();
                            break;
                        case 3:
                            Console.Clear();
                            RemoveCustomer();
                            break;
                        case 4:
                            
                            Console.Clear();
                            SearchCustomer();
                            break;
                        case 5:
                            ViewCustomerDetails();
                            break;
                        case 6:
                            SerializeCustomers();
                            break;
                        case 7:
                            DeserializeCustomers();
                            break;
                        case 8:
                            Environment.Exit(0);
                            break;
                        default:
                            Console.WriteLine("\nInvalid Choice!");
                            break;
                    }
                } while (choice != 6);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void PrintMenu()
        {
            Console.WriteLine("--------------------- CMS Main Menu --------------------");
            Console.WriteLine("1. Create Customer");
            Console.WriteLine("2. Modify Customer");
            Console.WriteLine("3. Remove Customer");
            Console.WriteLine("4. Search Customer");
            Console.WriteLine("5. View All Customer");
            Console.WriteLine("6. Serialize Customer Data");
            Console.WriteLine("7. Deserialize Customer Data");
            Console.WriteLine("8. Exit");
            Console.WriteLine("------------------------------------------------------------\n");

        }

        private static void CreateNewCustomer()
        {
            try
            {
                Customer newCustomer = new Customer();

                Console.Write("\nEnter Customer ID: ");
                newCustomer.CustomerID = Convert.ToInt32(Console.ReadLine());

                Console.Write("\nEnter Customer Name: ");
                newCustomer.CustomerName = Console.ReadLine();

                Console.Write("\nEnter Customer City: ");
                newCustomer.City = Console.ReadLine();

                Console.Write("\nEnter Customer Age: ");
                newCustomer.Age = Convert.ToInt32(Console.ReadLine());

                Console.Write("\nEnter Customer Phone Number : ");
                newCustomer.Phone = Convert.ToInt64(Console.ReadLine());

                Console.Write("\nEnter Customer Pincode : ");
                newCustomer.Pincode = Convert.ToInt32(Console.ReadLine());


                bool customerAdded = CustomerBL.AddCustomerBL(newCustomer);

                if (customerAdded)
                    Console.WriteLine("\nNew Customer created");
                else
                    Console.WriteLine("\nNew Customer not created");
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void ViewCustomerDetails()
        {
            try
            {
                List<Customer> customerList = CustomerBL.ListAllCustomersBL();
                if (customerList.Count > 0)
                {
                    Console.WriteLine("\n-------------------------------------------------------------------------------");
                    Console.WriteLine("CustomerID\tName\tCity\tAge\tPhone\tPinCode");
                    Console.WriteLine("-------------------------------------------------------------------------------");
                    foreach (Customer item in customerList)
                    {
                        Console.WriteLine($"{item.CustomerID}\t{item.CustomerName}\t{item.City}\t{item.Age}\t{item.Phone}\t{item.Pincode}");
                    }
                    Console.WriteLine("-------------------------------------------------------------------------------");

                }
                else
                {
                    Console.WriteLine("\nNo Customer details available");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchCustomer()
        {
            try
            {
                int choice;
                do
                {
                    Console.WriteLine("\n------------------Customer Search Menu------------------");
                    Console.WriteLine("1. Search By Customer ID");
                    Console.WriteLine("2. Search By Customer Name");
                    Console.WriteLine("3. Go Back to Main Menu");
                    Console.WriteLine("------------------------------------------------------\n");

                    Console.Write("\nEnter your Choice: ");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:

                            int searchID;
                            Console.Write("\nEnter Customer ID to searched: ");
                            searchID = Convert.ToInt32(Console.ReadLine());

                            Customer customer = CustomerBL.SearchCustomerByIdBL(searchID);

                            if (customer != null)
                            {
                                Console.WriteLine("\n-------------------------------------------------------------------------------");
                                Console.WriteLine("CustomerID\tName\t\tCity\t\tPinCode");
                                Console.WriteLine("-------------------------------------------------------------------------------");

                                Console.WriteLine($"{customer.CustomerID}\t\t{customer.CustomerName}\t\t{customer.City}\t\t{customer.Pincode}");

                                Console.WriteLine("-------------------------------------------------------------------------------");
                            }
                            else
                            {
                                Console.WriteLine("\nNo Customer details available");
                            }
                            break;
                        case 2:

                            string searchName;
                            Console.Write("\nEnter Customer Name to searched: ");
                            searchName = Console.ReadLine();

                            List<Customer> customerList = CustomerBL.SearchCustomerByNameBL(searchName);

                            if (customerList != null)
                            {
                                Console.WriteLine("\n-------------------------------------------------------------------------------");
                                Console.WriteLine("CustomerID\tName\t\tCity\t\tPinCode");
                                Console.WriteLine("-------------------------------------------------------------------------------");
                                foreach (Customer item in customerList)
                                {
                                    Console.WriteLine($"{item.CustomerID}\t\t{item.CustomerName}\t\t{item.City}\t\t{item.Pincode}");
                                }
                                Console.WriteLine("-------------------------------------------------------------------------------");


                            }
                            else
                            {
                                Console.WriteLine("\nNo Customer details available ");
                            }

                            break;
                        case 3:
                            Console.Clear();
                            return;
                        default:
                            Console.WriteLine("\nInvalid Choice");
                            break;
                    }
                } while (choice != 3);
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void ModifyCustomer()
        {
            try
            {
                int choice;
                do
                {

                    Console.WriteLine("\n------------------Customer Modify Menu------------------");
                    Console.WriteLine("1. Modify Customer Details By Customer ID");
                    Console.WriteLine("2. Modify Customer Details By Customer Name");
                    Console.WriteLine("3. Modify from Customer Summary");
                    Console.WriteLine("4. Go Back to Main Menu");
                    Console.WriteLine("------------------------------------------------------\n");

                    Console.Write("\nEnter your Choice:");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:

                            int updateID;
                            Console.Write("\nEnter Customer ID to modified: ");
                            updateID = Convert.ToInt32(Console.ReadLine());

                            Customer customer = CustomerBL.SearchCustomerByIdBL(updateID);

                            if (customer != null)
                            {
                                Console.WriteLine("-------------------------------------------------------------------------------");
                                Console.WriteLine("CustomerID\tName\t\tCity\t\tPhone_number\t\tPinCode");
                                Console.WriteLine("-------------------------------------------------------------------------------");

                                Console.WriteLine($"{customer.CustomerID}\t\t{customer.CustomerName}\t\t{customer.City}\t\t{customer.Phone}\t\t{customer.Pincode}");

                                Console.WriteLine("-------------------------------------------------------------------------------");

                                Console.Write("Enter new details:\n ");
                                Console.Write("\nEnter Customer Name: ");
                                customer.CustomerName = Console.ReadLine();

                                Console.Write("\nEnter Customer City: ");
                                customer.City = Console.ReadLine();

                                Console.Write("\nEnter Customer Age: ");
                                customer.Age = Convert.ToInt32(Console.ReadLine());

                                Console.Write("\nEnter Customer Phone Number : ");
                                customer.Phone = Convert.ToInt64(Console.ReadLine());

                                Console.Write("\nEnter Customer Pincode : ");
                                customer.Pincode = Convert.ToInt32(Console.ReadLine());

                                bool customerUpdated = CustomerBL.ModifyCustomerBL(customer);

                                if (customerUpdated)
                                    Console.WriteLine("\nCustomer data modified");
                                else
                                    Console.WriteLine("\nCustomer data not modified");
                            }
                            else
                            {
                                Console.WriteLine("\nNo Customer details available");
                            }

                            break;

                        case 2:

                            string updateName;
                            Console.Write("\nEnter Customer Name to modified: ");
                            updateName = Console.ReadLine();

                            List<Customer> customerList = CustomerBL.SearchCustomerByNameBL(updateName);

                            if (customerList.Count == 1)
                            {
                                Console.Write("\nEnter Customer Name: ");
                                customerList[0].CustomerName = Console.ReadLine();

                                Console.Write("\nEnter Customer City: ");
                                customerList[0].City = Console.ReadLine();

                                Console.Write("\nEnter Customer Age: ");
                                customerList[0].Age = Convert.ToInt32(Console.ReadLine());

                                Console.Write("\nEnter Customer Phone Number (10 digits): ");
                                customerList[0].Phone = Convert.ToInt64(Console.ReadLine());

                                Console.Write("\nEnter Customer Pincode (6 digits): ");
                                customerList[0].Pincode = Convert.ToInt32(Console.ReadLine());

                                bool customerUpdated = CustomerBL.ModifyCustomerBL(customerList[0]);

                                if (customerUpdated)
                                    Console.WriteLine("\nCustomer data modified");
                                else
                                    Console.WriteLine("\nCustomer data not modified");
                            }


                            else if (customerList.Count > 1)
                            {

                                Console.WriteLine($"\nThere are {customerList.Count} Customers with the Name {updateName} : \n");

                                Console.WriteLine("\n-------------------------------------------------------------------------------");
                                Console.WriteLine("CustomerID\tName\t\tCity\t\tPinCode");
                                Console.WriteLine("-------------------------------------------------------------------------------");
                                foreach (Customer item in customerList)
                                {
                                    Console.WriteLine($"{item.CustomerID}\t\t{item.CustomerName}\t\t{item.City}\t\t{item.Pincode}");
                                }
                                Console.WriteLine("-------------------------------------------------------------------------------");

                                int updateID1;
                                Console.Write("\nEnter Customer ID to modified: ");
                                updateID1 = Convert.ToInt32(Console.ReadLine());

                                Customer customer1 = CustomerBL.SearchCustomerByIdBL(updateID1);

                                if (customer1 != null)
                                {
                                    Console.Write("\nEnter Customer Name: ");
                                    customer1.CustomerName = Console.ReadLine();

                                    Console.Write("\nEnter Customer City: ");
                                    customer1.City = Console.ReadLine();

                                    Console.Write("\nEnter Customer Age: ");
                                    customer1.Age = Convert.ToInt32(Console.ReadLine());


                                    Console.Write("\nEnter Customer Phone Number (10 digits): ");
                                    customer1.Phone = Convert.ToInt64(Console.ReadLine());

                                    Console.Write("\nEnter Customer Pincode (6 digits): ");
                                    customer1.Pincode = Convert.ToInt32(Console.ReadLine());

                                    bool customerUpdated = CustomerBL.ModifyCustomerBL(customer1);

                                    if (customerUpdated)
                                        Console.WriteLine("\nCustomer data modified");
                                    else
                                        Console.WriteLine("\nCustomer data not modified");
                                }
                                else
                                {
                                    Console.WriteLine("\nNo Customer details available");
                                }


                            }
                            else
                            {
                                Console.WriteLine("\nNo Customer details available ");
                            }

                            break;
                        case 3:
                            ViewCustomerDetails();

                            int updateID2;
                            Console.Write("\nEnter Customer ID to modified: ");
                            updateID2 = Convert.ToInt32(Console.ReadLine());

                            Customer customer2 = CustomerBL.SearchCustomerByIdBL(updateID2);

                            if (customer2 != null)
                            {
                                Console.Write("\nEnter Customer Name: ");
                                customer2.CustomerName = Console.ReadLine();

                                Console.Write("\nEnter Customer City: ");
                                customer2.City = Console.ReadLine();

                                Console.Write("\nEnter Customer Age: ");
                                customer2.Age = Convert.ToInt32(Console.ReadLine());

                                Console.Write("\nEnter Customer Phone Number (10 digits): ");
                                customer2.Phone = Convert.ToInt64(Console.ReadLine());

                                Console.Write("\nEnter Customer Pincode (6 digits): ");
                                customer2.Pincode = Convert.ToInt32(Console.ReadLine());

                                bool customerUpdated = CustomerBL.ModifyCustomerBL(customer2);

                                if (customerUpdated)
                                    Console.WriteLine("\nCustomer data modified");
                                else
                                    Console.WriteLine("\nCustomer data not modified");
                            }
                            else
                            {
                                Console.WriteLine("\nNo Customer details available");
                            }
                            break;
                        case 4:
                            Console.Clear();
                            return;
                        default:
                            Console.WriteLine("\nInvalid Choice");
                            break;
                    }

                } while (choice != 4);

            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void RemoveCustomer()
        {
            try
            {
                int choice;
                do
                {

                    Console.WriteLine("\n------------------Customer Remove Menu------------------");
                    Console.WriteLine("1. Remove Customer By Customer ID");
                    Console.WriteLine("2. Remove Customer By Customer Name");
                    Console.WriteLine("3. Remove from Customer Summary");
                    Console.WriteLine("4. Go Back to Main Menu");
                    Console.WriteLine("------------------------------------------------------\n");

                    Console.WriteLine("\nEnter your Choice:");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:

                            int deleteID;
                            Console.WriteLine("\nEnter Customer ID to removed: ");
                            deleteID = Convert.ToInt32(Console.ReadLine());

                            Customer customer = CustomerBL.SearchCustomerByIdBL(deleteID);

                            if (customer != null)
                            {
                                bool customerDeleted = CustomerBL.RemoveCustomerBL(deleteID);

                                if (customerDeleted)
                                    Console.WriteLine("\nCustomer removed");
                                else
                                    Console.WriteLine("\nCustomer not removed ");
                            }
                            else
                            {
                                Console.WriteLine("\nNo Customer details available");
                            }

                            break;
                        case 2:

                            string deleteName;
                            Console.WriteLine("\nEnter Customer Name to removed: ");
                            deleteName = Console.ReadLine();

                            List<Customer> customerList = CustomerBL.SearchCustomerByNameBL(deleteName);

                            if (customerList.Count == 1)
                            {
                                bool customerDeleted = CustomerBL.RemoveCustomerBL(customerList[0].CustomerID);

                                if (customerDeleted)
                                    Console.WriteLine("\nCustomer removed");
                                else
                                    Console.WriteLine("\nCustomer not removed ");
                            }


                            else if (customerList.Count > 1)
                            {

                                Console.WriteLine($"\nThere are {customerList.Count} Customers with the Name {deleteName} : \n");

                                Console.WriteLine("-------------------------------------------------------------------------------");
                                Console.WriteLine("CustomerID\tName\t\tCity\t\tPinCode");
                                Console.WriteLine("-------------------------------------------------------------------------------");
                                foreach (Customer item in customerList)
                                {
                                    Console.WriteLine($"{item.CustomerID}\t\t{item.CustomerName}\t\t{item.City}\t\t{item.Pincode}");
                                }
                                Console.WriteLine("-------------------------------------------------------------------------------");

                                int deleteID1;
                                Console.WriteLine("\nEnter Customer ID to removed: ");
                                deleteID1 = Convert.ToInt32(Console.ReadLine());

                                Customer customer1 = CustomerBL.SearchCustomerByIdBL(deleteID1);

                                if (customer1 != null)
                                {
                                    bool customerDeleted = CustomerBL.RemoveCustomerBL(deleteID1);

                                    if (customerDeleted)
                                        Console.WriteLine("\nCustomer removed");
                                    else
                                        Console.WriteLine("\nCustomer not removed ");
                                }
                                else
                                {
                                    Console.WriteLine("\nNo Customer details available");
                                }


                            }
                            else
                            {
                                Console.WriteLine("\nNo Customer details available ");
                            }

                            break;
                        case 3:
                            ViewCustomerDetails();

                            int deleteID2;
                            Console.WriteLine("\nEnter Customer ID to removed: ");
                            deleteID2 = Convert.ToInt32(Console.ReadLine());

                            Customer customer2 = CustomerBL.SearchCustomerByIdBL(deleteID2);

                            if (customer2 != null)
                            {
                                bool customerDeleted = CustomerBL.RemoveCustomerBL(deleteID2);

                                if (customerDeleted)
                                    Console.WriteLine("\nCustomer removed");
                                else
                                    Console.WriteLine("\nCustomer not removed ");
                            }
                            else
                            {
                                Console.WriteLine("\nNo Customer details available");
                            }
                            break;
                        case 4:
                            Console.Clear();
                            return;
                        default:
                            Console.WriteLine("\nInvalid Choice");
                            break;
                    }

                } while (choice != 4);

            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SerializeCustomers()
        {
            try
            {
                bool customerSerialized = CustomerBL.SerializeCustomerBL();

                if (customerSerialized)
                {
                    Console.WriteLine("\nCustomer Data is Serialized");
                }
                else
                {
                    throw new CustomerException("\nCustomer Data is not Serialized");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void DeserializeCustomers()
        {
            try
            {
                List<Customer> deserializeCustList = CustomerBL.DeserializeCustomerBL();


                if (deserializeCustList.Count > 0)
                {
                    Console.WriteLine("\nDeserialized Customer data: \n");
                    Console.WriteLine("-------------------------------------------------------------------------------");
                    Console.WriteLine("CustomerID\tName\t\tCity\t\tPinCode");
                    Console.WriteLine("-------------------------------------------------------------------------------");
                    foreach (Customer item in deserializeCustList)
                    {
                        Console.WriteLine($"{item.CustomerID}\t\t{item.CustomerName}\t\t{item.City}\t\t{item.Pincode}");
                    }
                    Console.WriteLine("-------------------------------------------------------------------------------");

                }
                else
                {
                    throw new CustomerException("\nCustomer data not Deserialized");
                }
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
