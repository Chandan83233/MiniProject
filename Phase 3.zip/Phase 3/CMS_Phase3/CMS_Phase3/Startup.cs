﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(CMS_Phase3.Startup))]
namespace CMS_Phase3
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
