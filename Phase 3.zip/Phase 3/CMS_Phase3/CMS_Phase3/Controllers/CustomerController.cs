﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using CMS_Phase3.Models;

namespace CMS_Phase3.Controllers
{
    public class CustomerController : Controller
    {
        // GET: Customer
        
        
            CustomerEntities db = new CustomerEntities();
        //Index page showing customer list
        public ActionResult Index()
        {
            return View();
        }

        //Search by ID
        public ActionResult SearchByID(int? search)
            {
                List<Customer> CustomerList = db.Customers.Where(x => x.CustomerID == search).ToList();
                return View(CustomerList);

            }
            //Search by Name
            public ActionResult SearchByName(string search)
            {
                List<Customer> CustomerList = db.Customers.Where(x => x.CustomerName == search).ToList();
                return View(CustomerList);
            }

            //Create new customer
            public ActionResult AddCustomer()
            {
                return View();
            }

            [HttpPost]
            [ValidateAntiForgeryToken]
            public ActionResult AddCustomer([Bind(Include = "CustomerName,City,Age,Phone,Pincode")] Customer customer)
            {
                if (ModelState.IsValid)
                {
                    db.Customers.Add(customer);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }

                return View(customer);
            }

            //Update Customer by Id search
            public ActionResult UpdateByID(int? id)
            {
                List<Customer> CustomerList = db.Customers.Where(x => x.CustomerID == id).ToList();
                return View(CustomerList);
            }
            //Update Customer by Name search
            public ActionResult UpdateByName(string name)
            {
                List<Customer> CustomerList = db.Customers.Where(x => x.CustomerName == name).ToList();
                return View(CustomerList);
            }
            //Update Customer
            public ActionResult Edit(int? id)
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Customer customer = db.Customers.Find(id);
                if (customer == null)
                {
                    return HttpNotFound();
                }
                return View(customer);
            }

            [HttpPost]
            public ActionResult Edit([Bind(Include = "CustomerID,CustomerName,City,Age,Phone,Pincode")]Customer customer)
            {
                if (ModelState.IsValid)
                {
                    db.Entry(customer).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                return View(customer);
            }
            //Delete by ID search view
            public ActionResult DeleteByID(int? id)
            {
                List<Customer> CustomerList = db.Customers.Where(x => x.CustomerID == id).ToList();
                return View(CustomerList);
            }
            public ActionResult DeleteByName(string name)
            {
                List<Customer> CustomerList = db.Customers.Where(x => x.CustomerName == name).ToList();
                return View(CustomerList);
            }
            public ActionResult Delete(int? id)
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Customer customer = db.Customers.Find(id);
                if (customer == null)
                {
                    return HttpNotFound();
                }
                return View(customer);
            }

            // POST: Employee_46004682/Delete/5
            [HttpPost, ActionName("Delete")]
            //[ValidateAntiForgeryToken]
            public ActionResult DeleteIDConfirmed(int id)
            {
                Customer customer = db.Customers.Find(id);
                db.Customers.Remove(customer);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            //Search Menu view
            public ActionResult SearchMenu()
            {
                return View();
            }
            //Delete Menu view
            public ActionResult DeleteMenu()
            {
                return View();
            }
            //Update Menu view
            public ActionResult UpdateMenu()
            {
                return View();
            }
            public ActionResult ViewAllCustomer()
            {
            IEnumerable<Customer> customers = db.Customers.ToList();
                return View(customers);
            }
            protected override void Dispose(bool disposing)
            {
                if (disposing)
                {
                    db.Dispose();
                }
                base.Dispose(disposing);
            }
        }
    
}